# FieldMind board benchmarks, 7 October 2026: single agent vs multi-agent

For the teammate continuing the multi-agent accuracy work (branch `multi-agent-fix`). Everything here was measured on
the QIDK on 7 October 2026, except the folder marked as the 5 October reference. Agent code ran on the laptop and
only model calls ran on the board, so every tick time is a laptop time. Energy was not measured. All plant data is
synthetic. The six episodes are **reporting** episodes; per the project rules nothing here should be used to choose
a threshold or a rule (see section 8).

---

## 1. What is in this zip

| path | contents |
|---|---|
| `ANALYSIS.md` | this file |
| `multi_v2_6mark/` | multi-agent, six episodes (N01, A01, B01, C01, D01, E01), 7 Oct, all finished |
| `single_6mark/` | single agent, 7 Oct: N01 and A01 finished; B01 failed on a board disconnect (section 7) |
| `single_agent_2026-10-05_reference/` | single agent, all six episodes, 5 Oct, made with the old runner (`bench/stage_monitor.py`); the only single-agent data for B01–E01 |
| `tooling/` | the benchmark command used on 7 Oct and its guide (section 2). These files are **not in git yet**, so they are copied here |

Each benchmark folder holds `RESULTS.md` (one row per episode), `test.json` (settings and every run), `temps.jsonl`,
and per episode a `summary.json` (evaluation and call counts), a `run.json.gz` (every tick, with every prompt and raw
model reply), a `.log` and a `.lanes.txt` (the server startup lines proving NPU / CPU placement).

---

## 2. How the runs were made

Command: `scripts/benchmark.sh <test name> <episodes...> [options]`. The runner is `tooling/bench/benchmark.py` and
its guide `tooling/BENCHMARK_GUIDE.md`.

```
scripts/benchmark.sh multi_v2_6mark ep_N01_normal ep_A01_fcv_seize ep_B01_tube_leak \
    ep_C01_wet_coal ep_D01_high_cv_coal ep_E01_fouling_drift
scripts/benchmark.sh single_6mark ep_N01_normal ep_A01_fcv_seize ep_B01_tube_leak ... --arch single
```

| | multi-agent (`multi_v2_6mark`) | single agent (`single_6mark`) |
|---|---|---|
| code | branch `multi-agent-fix`, commit `8acbc13` (your latest) plus the uncommitted benchmark tooling (no agent code changed) | same |
| config | `configs/base.yaml` + `configs/fast.yaml`, `merge_rule: model` (the default, i.e. the old `merge`) | `configs/base.yaml`, no overlay |
| models | NPU lane: Llama 3.2 3B (water and heat diagnosticians); CPU lane: Gemma 3 1B (verifier, text reader) | NPU lane: Llama 3.2 3B (diagnostician and verifier) |
| answers | compact format, line numbers, answer grammar on (`multi.grammar`), caps 60 / 30 / 50 | the single agent's format, no grammar, cap 256 |
| mode | lockstep (back to back; each tick waits for its model answers) | lockstep (the single agent always is) |
| server flags | `-c 4096 -np 1 -fit off --cache-ram 0 -lv 4`, both lanes restarted fresh before every episode, NPU placement checked from the startup log | same, NPU lane only |
| prompts saved | yes (`--log-prompts`); `bench/replay_multi.py` works on these runs | yes |
| chip | cooled to within 5 °C of the batch-start reading before each episode | same |

The 5 October single-agent reference used the same model file and server flags with the older runner
(`bench/stage_monitor.py`, no prompts saved). The single agent's code (`fieldmind/agent/`) has not changed since then.

---

## 3. Results

### 3.1 Multi-agent, six episodes (`multi_v2_6mark`)

| episode | group top-1 | belief alone | exact top-1 | top-3 | faithfulness | actions P / R | lead time min | model calls | unusable | tokens in | tick median / max s | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| N01 normal | – | – | – | – | 1.00 | – | – (0 false alarms) | 5 | 0 | 2,013 | quiet | 17 |
| A01 feed valve seizure | 0.59 | 0.55 | 0.22 | 0.89 | 1.00 | 0.31 / 1.00 | 20.2 | 72 | 0 | 46,871 | 2.6 / 5.2 | 204 |
| B01 tube leak | **0.09** | 0.56 | 0.09 | 0.63 | 1.00 | 0.57 / 1.00 | – | 95 | 0 | 57,167 | 1.9 / 6.2 | 248 |
| C01 wet coal (held-out case) | 0.79 | 0.98 | n/a | n/a | 1.00 | 0.43 / 0.75 | – | 30 | 0 | 21,594 | 2.8 / 4.9 | 94 |
| D01 high-CV coal | **0.03** | 0.82 | 0.03 | 0.89 | 1.00 | 0.40 / 1.00 | **−12.7** | 147 | 0 | 96,584 | 2.0 / 6.3 | 435 |
| E01 fouling drift | – | – | – | – | 1.00 | – | – | 10 | 0 | 4,035 | quiet | 27 |

Definitions:
- **Group top-1:** the share of scored ticks (fault onset onward) whose published rank-1 cause is in the true case's
  look-alike group (`data/kb/case_groups.json`).
- **Belief alone:** the same share for the code-only ranking.
- **Lead time:** the minutes between the first exact correct call and the trip; negative means after the trip.

Every value comes from `bench/evaluator.py` via the summaries.

### 3.2 Single agent

| episode | run | group top-1 | belief alone | exact top-1 | faithfulness | actions P / R | lead time min | ticks over 30 s | wall s |
|---|---|---|---|---|---|---|---|---|---|
| N01 | 7 Oct | – | – | – | 1.00 | – | – (0 false alarms) | 0 | 8 |
| A01 | 7 Oct | 0.56 | 0.55 | 0.17 | 0.76 | 0.27 / 1.00 | 17.2 | 19 of 106 | 2,113 |
| A01 | 5 Oct | 0.56 | 0.55 | 0.16 | 0.74 | 0.27 / 1.00 | 16.7 | 15% of ticks | 2,161 |
| B01 | 5 Oct | 0.66 | 0.56 | 0.66 | 0.84 | 0.36 / 1.00 | – | 19% of ticks | 2,837 |
| C01 | 5 Oct | 0.67 | 0.98 | n/a | 0.98 | 0.50 / 1.00 | – | 3% of ticks | 785 |
| D01 | 5 Oct | 0.80 | 0.82 | 0.80 | 0.95 | 0.57 / 1.00 | 108.3 | 8% of ticks | 4,181 |

The single agent reproduces: A01 group top-1 was 0.557 on both days.

---

## 4. Head to head on A01 (both 7 Oct)

| | multi-agent | single agent |
|---|---|---|
| group top-1 | 0.59 | 0.56 |
| true case in top 3 | 0.89 | 0.63 |
| first correct call | tick 38 | tick 44 |
| faithfulness | 1.00 | 0.76 |
| unusable answers | 0 of 72 | 14 of 147 (11 verifier "no JSON found", 3 diagnoses) |
| tokens in / out | 47 k / 2.2 k | 234 k / 25.3 k |
| median non-quiet tick | 2.6 s | 16.1 s |
| ticks over 30 s | 0 | 19 of 106 (worst 47.2 s) |
| wall time | 204 s | 2,113 s |
| chip | 38 → 61 °C | 37 → 65 °C |

- **Accuracy is a tie within noise.** 3 ticks out of 106; earlier, two identical runs differed on 10 of 37 replies.
- **They are right on different ticks:** both right on 44, only the multi-agent on 19, only the single agent on 15,
  neither on 28.
- **Both oscillate between the same causes:** RCA-16 (feed-pump cavitation, same group as the true case), RCA-01
  (the true case) and RCA-15.
- **By plant state,** the multi-agent is ahead in DEVIATION and ALARM; the single agent and belief are better at
  TRIP_IMMINENT (11 and 13 of 15 against 9).
- **Shown confidence does not separate right from wrong.** Multi-agent: 0.26 on right ticks, 0.22 on wrong. Single
  agent: 0.33 against 0.30.
- **On 7 scored ticks the single agent published a rank-1 with no library case** (`case_ref` None), scored wrong.

---

## 5. The main finding: the multi-agent model overrides a correct code ranking

On B01 and D01 the code-only ranking (belief) was right most of the time. The published ranking almost never was.

| episode | belief rank-1 right | published rank-1 right | ticks belief right, model made wrong |
|---|---|---|---|
| A01 | 58 RCA-01 of 106 | see section 4 | 38 |
| B01 | 71 RCA-11 of 128 | 12 RCA-11 | 65 |
| D01 | 182 RCA-07 of 221 | 7 RCA-07 | 182 |

### 5.1 Mechanism: `merge` puts the model's order first

`fieldmind/agent/orchestrator.merge` (reused by `gate.fold_sides` under `merge_rule: model`):
- the cases the model named go first, in the model's order;
- belief's other cases are appended after them;
- each case keeps belief's confidence, and a case belief does not hold gets 0.30.

D01 tick 121:

| | rank 1 | rank 2 | rank 3 | rank 4 |
|---|---|---|---|---|
| belief | RCA-07 0.98 | RCA-14 0.82 | RCA-18 0.82 | RCA-13 0.56 |
| published | **RCA-10 0.30** | RCA-09 0.30 | RCA-07 0.98 | RCA-14 0.82 |

The published list is not in confidence order. Rank 1 is what the engineer reads, what actions follow, and what is
scored. Belief itself is untouched (the next tick still has RCA-07 at 0.98), which is why replay works.

### 5.2 Why the model picks the wrong case

That tick-121 prompt is saved in `multi_v2_6mark/ep_D01_high_cv_coal_multi.run.json.gz`.

What the prompt contained:
- facts: bed rising, "energy accumulating in bed", ms temperature drifting;
- case line 1: RCA-07, with exactly that signature;
- the record "CV notably above the calibration basis";
- "belief (from code): RCA-07 0.98".

Llama 3B answered `{"g":"B","r":[[3,[4,5]],[2,[4]]],...}`: RCA-10 ("occurs only during light-up"), whose signature
is all FLAT.

| episode | answers | true group among cases shown | model ranked it first | first case an all-FLAT filler (RCA-09/10/15) | filler cases per prompt |
|---|---|---|---|---|---|
| A01 | 57 | 39 | 32 | 10 | 0.8 |
| B01 | 52 | 49 | 4 | 29 | 1.6 |
| C01 | 25 | 20 | 20 | 5 | 1.6 |
| D01 | 96 | 77 | 2 | 57 | 2.0 |

Contributing factors seen in the data. Each is a measured pattern; none has been tested as a cause:
1. **The all-FLAT cases (RCA-09, 10, 15) are shown to both sides** (`sides.case_sides`: no moving triple means both
   sides) and fill the case list. The model picks them first in 57 of 96 D01 answers.
2. **The leading group letter.** The answer starts with `"g"`, and the grammar forces it first. The model usually
   writes the most common letter among the shown cases (76 of 96 on D01, where the three fillers share letter B), then
   ranks a case of that letter first (72 of 96).
3. **The worked example is not echoed literally** (1 of 205 answers equals the example ranking). Answers do favour
   short low-line patterns, e.g. `[[3,[1,2,3]],[1,[1]]]` 27 times on D01.
4. **The note reader injects false plant facts.** Under the grammar, Gemma 1B must pick vocabulary words, so
   distractor notes become facts in the diagnosis prompt:

   | raw note | note-fact given to the diagnostician |
   |---|---|
   | "fire ext refill due this month" | `FEED_VALVE DOWN` |
   | "ash slurry pump 2 tripped twice" | `steam_flow DOWN` |
   | "lab report says CV higher" | `COAL_CV CHOKED` |
   | "CT fan 3 belt slipping" | `drum_level DOWN` |

   Every reading has kind `OTHER`. Its effect on the ranking is not measured.

These match the causes listed in `reports/multi_accuracy_fix.md`.

### 5.3 Offline replay of the merge rules on these runs

`bench/replay_multi.py`, the same saved answers, no new model calls. `current` reproduces the published values, so
the replay is faithful on these runs. Its D01 scored-tick count is 223 against the evaluator's 221 (not
investigated).

| episode | current (`model`) | `tiebreak` | `nudge` | belief alone |
|---|---|---|---|---|
| A01 | 0.594 | 0.566 | **0.670** | 0.547 |
| B01 | 0.094 | 0.375 | 0.500 | **0.555** |
| C01 | 0.791 | 0.977 | **1.000** | 0.977 |
| D01 | 0.031 | **0.843** | 0.812 | 0.816 |
| mean of the four | 0.38 | 0.69 | **0.75** | 0.72 |

Single agent on the same four (A01 7 Oct, others 5 Oct): mean 0.67.

- **Any rule that keeps belief's order as the base removes the collapse.** `nudge` is above belief alone on three
  of the four.
- **B01 stays below belief under every rule,** so the model's answers on the water side of a tube leak are worse
  than no model.
- These are replays on reporting episodes; the rule is to be chosen on the dev set (your decision 5 / quick set).

---

## 6. Speed, cost and reliability (where the multi-agent clearly wins)

- **About 10× faster per episode:**

  | episode | multi-agent | single agent |
  |---|---|---|
  | A01 | 204 s | 2,113 s |
  | B01 | 248 s | 2,837 s |
  | C01 | 94 s | 785 s |
  | D01 | 435 s | 4,181 s |

- **No tick over the 30 s budget.** Worst non-quiet tick 6.3 s, against up to 47 s for the single agent.
- **0 unusable answers in 359 multi-agent calls.** The grammar makes wrong-format answers impossible, so this says
  nothing about the model, only about the format.
- **Faithfulness 1.00 on every episode.** Answers can only cite the line numbers shown.
- **Median call times:** diagnostician 2.9–3.2 s, verifier 1.8–2.1 s, note reader 1.5–1.9 s. Median input about
  700 tokens per diagnosis against about 1,800 for the single agent.
- **Chip:** multi-agent episodes ended at 51–66 °C, single-agent A01 at 65 °C.

---

## 7. Problems found (not fixed)

1. **The single-agent B01 run crashed instead of degrading.** At 17:14 the board connection dropped mid-call: the
   temperature read straight afterwards also failed (`temps.jsonl`, `max_c: null`). The model call raised
   `http.client.RemoteDisconnected`. `LlamaServerBackend.generate` (`fieldmind/runtime/llm_backend.py`) catches
   `HTTPError`, timeouts and `URLError`, but not `RemoteDisconnected` / `ConnectionResetError`, so `run_demo.py`
   died instead of recording a failed call. The partial attempt is kept as
   `single_6mark/ep_B01_tube_leak_single.interrupted-20261007T171400.*` (ticks up to 50, all quiet). The cause of
   the disconnect (USB, adb, or the server crashing) is not known.
2. **Note reader with grammar** (section 5.2, item 4): rejected readings became accepted wrong ones.
3. **Replay tick count:** D01 223 against the evaluator's 221 scored ticks.
4. **Verifier call counts** differ between runs of the same episode in both directions (Phase 4b report); not
   investigated.

---

## 8. Caveats

- One run per system per episode, on reporting episodes. By project rule, decisions (merge rule, prompt changes) are
  made on dev; these numbers explain, they do not decide.
- **The single-agent B01–E01 reference is from 5 October,** made with the older runner. Same model, flags and agent
  code, but a different day and runner.
- **The multi-agent and single agent differ on several things at once:** grammar, prompt size, answer cap, side
  split, merge, verifier model. A difference cannot be pinned to one of them.
- **Tick times are laptop times.** Model calls ran on the board over adb port forwarding.
- **No energy figures** (`energy_mwh: null` everywhere).
- **C01's true case (RCA-06) is held out** of the library: only group credit is possible there.

---

## 9. Suggested next steps

1. **Run your step-1 board measurement with the benchmark command** on the dev quick set, once per rule, under
   separate test names (the command refuses to mix settings under one name):
   ```
   scripts/benchmark.sh dev_quick_model dev_A01_fcv_seize dev_A02_fcv_seize_fast dev_B01_tube_leak \
       dev_B02_tube_leak_fast dev_C01_wet_coal dev_C02_feeder_trip dev_D01_high_cv_coal \
       dev_D03_high_cv_severe dev_N01_normal dev_N02_normal --overlay configs/accuracy.yaml --merge-rule model
   ```
   Then the same with `--merge-rule tiebreak` and `nudge` (or replay the `model` run offline).
2. **Stop showing the all-FLAT cases to the diagnosticians** (or show them only when no moving case is retrieved).
3. **Remove the leading `"g"`** from the answer format and grammar (your step 2).
4. **Turn the Gemma note reader off** (your decision 3), or allow a "none of these" subject so the grammar does not
   force a fact.
5. **Catch `RemoteDisconnected` / `ConnectionResetError` in `LlamaServerBackend.generate`** as a failed call.
   This needs agreement, since it touches the shared runtime.
6. **Re-run single-agent B01–E01** with the new command for a same-day reference:
   `scripts/benchmark.sh single_6mark ... --arch single` resumes at B01.

---

## 10. Reading the files

- `summary.json`:
  - `meta`: settings, git, times, chip temperatures;
  - `evaluation`: the full `bench/evaluator.py` output (T1–T9, S1–S7);
  - `calls`: per agent, calls, unusable answers, tokens in / out, median call time.
- `run.json.gz`: the harness's run dict. Each assessment has `hypotheses` (published), `belief_ranking` and
  `belief_order` (code), `envelopes` (every call, with `prompt`, `raw_reply`, `tokens`, `latency_ms`) and, for the
  multi-agent, `multi` (compact answer records with the case and fact ids each line stood for, side, merge records,
  note readings).
- Replay: `.venv/bin/python bench/replay_multi.py --rule nudge multi_v2_6mark/*_multi.run.json.gz`.
- Live view of any run: `.venv/bin/python bench/stage_monitor_multi.py` (in `tooling/`); the columns are explained in
  `tooling/BENCHMARK_GUIDE.md` section 7.
